public class TicTacToe {
    public static void main(String[] args) {
        GameController gameController = new GameController();
        gameController.startGame();  // Запуск игры, затем вызов меню
    }
}
